function countQuery(input, query) {
  const freq = new Map();
  for (const word of input) {
    freq.set(word, (freq.get(word) || 0) + 1);
  }
  // console.log(freq);
  return query.map((q) => freq.get(q) || 0);
}

const INPUT = ["xc", "dz", "bbb", "dz"];
const QUERY = ["bbb", "ac", "dz"];

console.log(countQuery(INPUT, QUERY));
// console.log(countQuery(["a", "b", "a", "c"], ["a", "b", "z"]));
