function reverseAlphabet(str) {
  const letters = str.match(/[A-Za-z]/g) || [];
  const digits = str.match(/[0-9]/g) || [];
  return letters.reverse().join("") + digits.join("");
}

const input = "NEGIE1";
console.log(`Input : ${input}`);
console.log(`Output: ${reverseAlphabet(input)}`); 

// console.log(reverseAlphabet("HELLO123")); 
// console.log(reverseAlphabet("QWE9"));     
