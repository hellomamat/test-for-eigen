function longest(sentence) {
  const words = sentence.split(" ");
  // const words = sentence.split(/\s+/).filter(Boolean);
  let result = "";
  for (const word of words) {
    // console.log({ result, word });
    if (word.length > result.length) {
      result = word;
    }
  }
  return `${result}: ${result.length} character`;
}

const sentence = "Saya sangat senang mengerjakan soal algoritma";
console.log(longest(sentence));

// console.log(longest("aku suka makan nasi goreng"));
// console.log(longest("aku uduluh bla bla bla idilihh"));
